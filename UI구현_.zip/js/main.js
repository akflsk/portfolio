
$(".main>.fa").click(function () {
   $("#back").stop().slideToggle(300);
 });


$(".port").click(function(){
    $(".site").stop().slideToggle(300);
 });


 
