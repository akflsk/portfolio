
/*
$(".xs").mousemove(function(evt){
    var delta = 30;
    var cY = evt.clientY;
    var iY = $(this).find(".phone").height()/2;
    var mY = (iY - cY)/delta;
    $(this).find(".phone").css("transform","translate("+mY+"px)")
});
*/

var meChk = false;

$("#me").click(function(){
    if(!meChk) {
        $(".xs").stop().animate({"left":"20%"},500, "linear", function(){
            $(this).stop().animate({"top":"-5%"}, 1500, "swing");
            $("#cont_about").stop().animate({"top":"9%"}, 1500, "linear");
            meChk = true;
        });
    }
    else {
        $("#cont_skill").stop().css({"top":"110%"});
        $("#cont_about").stop().animate({"top":"9%"}, 1500, "linear");
    }
});

$("#skill").click(function(){
    if(!meChk) {
        $(".xs").stop().animate({"left":"20%"},500, "linear", function(){
            $(this).stop().animate({"top":"-5%"}, 1500, "swing");
            $("#cont_skill").stop().animate({"top":"9%"}, 1500, "linear");
            meChk = true;
        });
    }
    else {
        $("#cont_about").stop().css({"top":"110%"});
        $("#cont_skill").stop().animate({"top":"9%"}, 1500, "linear");
    }
});



